# Potato Launcher
An application that uses the Epic API to make your experience with Fortnite more convenient.

We are in no way associated with Epic Games.

# Developers
a.bakedpotato, m4tonoob, Otavio
## Helpers
- Alaattin - Great Feature/QOL Suggestions
- Amrsatrio - Epic API Help, UI Suggestions
- FortOfFans - Legally required to credit
- tb24 - Template ID List

# How to download
- v2.0.0-v2.2.3: Download the latest zip under releases.
- v2.2.4-Recent: Download the latest exe under releases and run it. The app should be installed at `%localappdata%\Programs\potato-launcher\potato-launcher.exe`.

# Future Plans
### v2.3
- Block List ✅
- Llama Shop ✅
- Save the World Shop
- Ventures Lookup ✏
### v2.4
- Hero Loadout Lookup
- Hero Loadout Management
- Manage Schematics
- Schematic Lookup
### v2.5
- Manage Survivor Squads
- Manage Survivors
- Survivor Lookup
- Survivor Squad Lookup
