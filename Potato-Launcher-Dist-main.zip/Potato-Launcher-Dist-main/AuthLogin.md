# How to Login (v2.2.0+)
Opening `Add Account` will open a url in the browser. You have to copy + paste the 32 digit code from it. See attached image.

![authlogin](https://user-images.githubusercontent.com/77371158/115131418-e465cc00-9fac-11eb-9fae-172a83c37dd2.png)
